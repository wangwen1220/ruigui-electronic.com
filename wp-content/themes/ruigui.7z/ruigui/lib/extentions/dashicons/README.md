dashicons
=========

This is the temporary home of Dashicons, the new WordPress core icon font. 

For new icon requests, please post to this core trac ticket: https://core.trac.wordpress.org/ticket/26936#ticket

For any issues that appear within WordPress core, please create a new ticket on https://core.trac.wordpress.org/. Use the "administration" component and the "UI" focus when creating the new ticket, and be sure to include "Dashicons" somewhere in the text of the ticket.

For issues related just to this demo page, please create new issues here.

Dashicons is licensed under GPLv2, or any later version with font exception (http://www.gnu.org/licenses/gpl-faq.html#FontException)
