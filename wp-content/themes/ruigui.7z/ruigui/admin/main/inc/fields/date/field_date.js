/*global jQuery*/

jQuery(document).ready(function () {
  jQuery('.redux-datepicker').datepicker();
});