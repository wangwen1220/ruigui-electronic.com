<?php
/**
 * The main template file.
 *
 * @package ThinkUpThemes
 */

get_header(); ?>

<?php get_footer() ?>